*&---------------------------------------------------------------------*
*&  Include           ZFI_OCV_TO_OVL_TRANSFER_E01
*&---------------------------------------------------------------------*
*& Description : Event blocks for the report
*&               - INITIALIZATION
*&               - AT SELECTION-SCREEN
*&               - START-OF-SELECTION
*&               - END-OF-SELECTION
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
* INITIALIZATION - default selection screen values
*----------------------------------------------------------------------*
INITIALIZATION.

* Default period to current period if not provided
  IF p_perio IS INITIAL.
    p_perio = sy-datum+4(2).
  ENDIF.

*----------------------------------------------------------------------*
* AT SELECTION-SCREEN - input validation
*----------------------------------------------------------------------*
AT SELECTION-SCREEN.

* Validate Company Code exists in T001
  PERFORM validate_company_code USING p_bukrs.

* Validate Fiscal Year (reasonable range)
  PERFORM validate_fiscal_year USING p_year.

* Validate Period (must be 1-16)
  PERFORM validate_period USING p_perio.

*----------------------------------------------------------------------*
* START-OF-SELECTION - main processing
*----------------------------------------------------------------------*
START-OF-SELECTION.

* Step 1: Load mapping tables (JV, GL, Cost Center, WBS, Profit Center)
  PERFORM load_mapping_tables.

* Step 2: Read source data from JVSO1 for the given selection criteria
  PERFORM read_jvso1_data.

* Step 3: Aggregate (subtotal) data by key fields
*         RJVNAM / RRECIN / RACCT / RCNTR / RORDNR / RPROJK / RPRCTR
  PERFORM aggregate_source_data.

* Step 4: Determine sender and receiver company code currencies
*         using FM JV_AND_FI_CURRENCIES
  PERFORM determine_currencies.

* Step 5: Apply mapping logic - resolve receiver values for each line
  PERFORM apply_mappings.

* Step 6: Derive posting/document date (last day of selection period)
  PERFORM derive_posting_date.

* Step 7: Post documents via BAPI_ACCOUNTING_DOCUMENT_POST
*         (BAPI is skipped if test run flag is set)
  PERFORM post_documents.

*----------------------------------------------------------------------*
* END-OF-SELECTION - display results
*----------------------------------------------------------------------*
END-OF-SELECTION.

* Display the processing log (ALV or classic list output)
  PERFORM display_log.
