*&---------------------------------------------------------------------*
*&  Include           ZFI_OCV_TO_OVL_TRANSFER_TOP
*&---------------------------------------------------------------------*
*& Description : Global Data Declarations
*&               - Types, Internal Tables, Work Areas, Constants
*&               - Selection Screen elements
*&               - Custom mapping tables (ZJVMAP, ZGLMAP, ZCSKMAP,
*&                 ZWBSMAP, ZPCMAP)
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
* TABLES DECLARATION
*----------------------------------------------------------------------*
TABLES: jvso1,         " JV Summary table - Ledger postings
        t001,          " Company Codes
        t8jv,          " Joint Venture Master
        t8jj,          " JV Recovery Indicators
        skb1,          " G/L account master (Company Code)
        csks,          " Cost Center Master Data
        prps,          " WBS (Work Breakdown Structure) Element Master
        cepc.          " Profit Center Master Data

*----------------------------------------------------------------------*
* TYPE DECLARATIONS
*----------------------------------------------------------------------*
TYPES:
*  Structure to hold data fetched from JVSO1 (source venture data)
  BEGIN OF ty_jvso1,
    rldnr   TYPE jvso1-rldnr,    " Ledger (4A / 4C)
    rrcty   TYPE jvso1-rrcty,    " Record Type (0)
    rvers   TYPE jvso1-rvers,    " Version (1)
    ryear   TYPE jvso1-ryear,    " Fiscal Year
    poper   TYPE jvso1-poper,    " Posting Period
    rbukrs  TYPE jvso1-rbukrs,   " Company Code
    rjvnam  TYPE jvso1-rjvnam,   " Joint Venture
    rrecin  TYPE jvso1-rrecin,   " Recovery Indicator
    racct   TYPE jvso1-racct,    " G/L Account
    regrou  TYPE jvso1-regrou,   " Equity group
    rcntr   TYPE jvso1-rcntr,    " Cost Center
    rordnr  TYPE jvso1-rordnr,   " Order Number
    rprojk  TYPE jvso1-rprojk,   " WBS Element (object number)
    rprctr  TYPE jvso1-rprctr,   " Profit Center
    tsl     TYPE jvso1-tsl,      " Amount in Transaction Currency
    hsl     TYPE jvso1-hsl,      " Amount in Local Currency
    ksl     TYPE jvso1-ksl,      " Amount in Group Currency
    budat   TYPE jvso1-budat,    " Posting Date
    rtcur   TYPE jvso1-rtcur,    " Transaction Currency
  END OF ty_jvso1,

*  Structure used after subtotalling/aggregation by key fields
  BEGIN OF ty_aggregated,
    rbukrs  TYPE jvso1-rbukrs,   " Source Company Code
    rjvnam  TYPE jvso1-rjvnam,   " Source JV
    rrecin  TYPE jvso1-rrecin,   " Source Recovery Indicator
    racct   TYPE jvso1-racct,    " Source GL Account
    rcntr   TYPE jvso1-rcntr,    " Source Cost Center
    rordnr  TYPE jvso1-rordnr,   " Source Order
    rprojk  TYPE jvso1-rprojk,   " Source WBS
    rprctr  TYPE jvso1-rprctr,   " Source Profit Center
    tsl     TYPE jvso1-tsl,      " Aggregated TC amount
    hsl     TYPE jvso1-hsl,      " Aggregated LC amount
    ksl     TYPE jvso1-ksl,      " Aggregated GC amount
    budat   TYPE jvso1-budat,    " Posting Date (used to derive period end)
    rtcur   TYPE jvso1-rtcur,    " Transaction currency of source
  END OF ty_aggregated,

*  Structure to hold final mapped data ready for BAPI posting
  BEGIN OF ty_post,
*   Source side
    src_bukrs  TYPE bukrs,
    src_jv     TYPE jv_name,
    src_recin  TYPE jv_recind,
    src_acct   TYPE racct,
    src_cntr   TYPE kostl,
    src_order  TYPE aufnr,
    src_wbs    TYPE ps_posid,
    src_prctr  TYPE prctr,
*   Target / Receiver side (after mapping)
    rec_bukrs  TYPE bukrs,
    rec_jv     TYPE jv_name,
    rec_recin  TYPE jv_recind,
    rec_acct   TYPE racct,
    rec_cntr   TYPE kostl,
    rec_order  TYPE aufnr,
    rec_wbs    TYPE ps_posid,
    rec_prctr  TYPE prctr,
*   Amounts and currencies
    tsl        TYPE jvso1-tsl,
    hsl        TYPE jvso1-hsl,
    ksl        TYPE jvso1-ksl,
    src_curr   TYPE waers,    " Source currency
    rec_curr   TYPE waers,    " Receiver currency
    budat      TYPE budat,    " Source posting date
    post_date  TYPE budat,    " Derived month-end posting date
    doc_date   TYPE budat,    " Document date (= post_date)
  END OF ty_post,

*  ---------------------------------------------------------------------
*  Mapping Table Structures
*  NOTE: These represent the Z-custom mapping tables described in the FS.
*  Z-table names assumed:
*    ZJVMAP   - Mapping for Company Code / JV / Recovery Indicator
*    ZGLMAP   - Mapping for GL Accounts
*    ZCSKMAP  - Mapping for Cost Centers
*    ZWBSMAP  - Mapping for WBS Elements
*    ZPCMAP   - Mapping for Profit Centers
*  ---------------------------------------------------------------------

*  JV / Recovery Indicator Mapping (Operating -> Receiving)
  BEGIN OF ty_jv_map,
    op_bukrs  TYPE bukrs,        " Operating Company Code
    op_jv     TYPE jv_name,      " Operating JV (VTYPE 2 or 5)
    op_recin  TYPE jv_recind,    " Operating Recovery Indicator
    rc_bukrs  TYPE bukrs,        " Receiving Company Code
    rc_jv     TYPE jv_name,      " Receiving JV (VTYPE 2 or 5)
    rc_recin  TYPE jv_recind,    " Receiving Recovery Indicator
  END OF ty_jv_map,

*  GL Mapping (Operating -> Receiving)
  BEGIN OF ty_gl_map,
    op_bukrs  TYPE bukrs,
    op_gl     TYPE racct,
    rc_bukrs  TYPE bukrs,
    rc_gl     TYPE racct,
  END OF ty_gl_map,

*  Cost Center Mapping
  BEGIN OF ty_csk_map,
    op_bukrs  TYPE bukrs,
    op_cntr   TYPE kostl,
    rc_bukrs  TYPE bukrs,
    rc_cntr   TYPE kostl,
  END OF ty_csk_map,

*  WBS Mapping
  BEGIN OF ty_wbs_map,
    op_bukrs  TYPE bukrs,
    op_wbs    TYPE ps_posid,
    rc_bukrs  TYPE bukrs,
    rc_wbs    TYPE ps_posid,
  END OF ty_wbs_map,

*  Profit Center Mapping
  BEGIN OF ty_pc_map,
    op_bukrs  TYPE bukrs,
    op_prctr  TYPE prctr,
    rc_bukrs  TYPE bukrs,
    rc_prctr  TYPE prctr,
  END OF ty_pc_map,

*  Structure to hold log / processing messages
  BEGIN OF ty_log,
    src_bukrs  TYPE bukrs,
    src_jv     TYPE jv_name,
    rec_bukrs  TYPE bukrs,
    rec_jv     TYPE jv_name,
    belnr      TYPE belnr_d,        " Posted Document Number
    gjahr      TYPE gjahr,           " Fiscal Year of posted doc
    msgtyp     TYPE bapi_mtype,      " Message type (S/E/W/I)
    message    TYPE string,          " Message Text
  END OF ty_log.

*----------------------------------------------------------------------*
* INTERNAL TABLES & WORK AREAS
*----------------------------------------------------------------------*
DATA:
*  Source data fetched from JVSO1
  gt_jvso1       TYPE STANDARD TABLE OF ty_jvso1,
  gs_jvso1       TYPE ty_jvso1,

*  Aggregated/subtotalled data
  gt_aggregated  TYPE STANDARD TABLE OF ty_aggregated,
  gs_aggregated  TYPE ty_aggregated,

*  Final data ready for BAPI posting
  gt_post        TYPE STANDARD TABLE OF ty_post,
  gs_post        TYPE ty_post,

*  Mapping tables (loaded once in start-of-selection)
  gt_jv_map      TYPE STANDARD TABLE OF ty_jv_map,
  gt_gl_map      TYPE STANDARD TABLE OF ty_gl_map,
  gt_csk_map     TYPE STANDARD TABLE OF ty_csk_map,
  gt_wbs_map     TYPE STANDARD TABLE OF ty_wbs_map,
  gt_pc_map      TYPE STANDARD TABLE OF ty_pc_map,

*  Log table for ALV / spool output
  gt_log         TYPE STANDARD TABLE OF ty_log,
  gs_log         TYPE ty_log.

*----------------------------------------------------------------------*
* BAPI Working Tables - BAPI_ACCOUNTING_DOCUMENT_POST
*----------------------------------------------------------------------*
DATA:
  gs_doc_header  TYPE bapiache09,                    " Doc header data
  gt_accountgl   TYPE STANDARD TABLE OF bapiacgl09,  " GL line items
  gs_accountgl   TYPE bapiacgl09,
  gt_currency    TYPE STANDARD TABLE OF bapiaccr09,  " Currency / amounts
  gs_currency    TYPE bapiaccr09,
  gt_return      TYPE STANDARD TABLE OF bapiret2,    " BAPI return msgs
  gs_return      TYPE bapiret2,
  gv_obj_type    TYPE bapiache09-obj_type,
  gv_obj_key     TYPE bapiache09-obj_key,
  gv_obj_sys     TYPE bapiache09-obj_sys.

*----------------------------------------------------------------------*
* GLOBAL VARIABLES
*----------------------------------------------------------------------*
DATA:
  gv_src_curr    TYPE waers,           " Sender company code currency
  gv_rec_curr    TYPE waers,           " Receiver company code currency
  gv_post_date   TYPE budat,           " Last day of period
  gv_doc_count   TYPE i,               " Number of docs posted
  gv_err_count   TYPE i,               " Number of errors
  gv_itemno      TYPE posnr_acc.       " Running item number for BAPI

*----------------------------------------------------------------------*
* CONSTANTS
*----------------------------------------------------------------------*
CONSTANTS:
*  Ledger values to be processed (per FS)
  gc_ledger_4a   TYPE rldnr  VALUE '4A',
  gc_ledger_4c   TYPE rldnr  VALUE '4C',
*  Record type and version filters (per FS)
  gc_rrcty       TYPE rrcty  VALUE '0',
  gc_rvers       TYPE rvers  VALUE '1',
*  VTYPE filter for valid JVs (per FS - only 2 and 5 allowed)
  gc_vtype_2     TYPE jv_vtype VALUE '2',
  gc_vtype_5     TYPE jv_vtype VALUE '5',
*  Document type for BAPI posting
*  NOTE: Field not specified in FS - assumed 'SA' (G/L Account Document).
*  To be confirmed with functional consultant / configured per business
*  requirement.
  gc_doc_type    TYPE blart   VALUE 'SA',
*  Debit / Credit indicators
  gc_debit       TYPE shkzg   VALUE 'S',
  gc_credit      TYPE shkzg   VALUE 'H',
*  Username for BAPI header
  gc_username    TYPE syuname VALUE sy-uname.

*----------------------------------------------------------------------*
* SELECTION SCREEN
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-b01.

* Company Code (mandatory - operating company code from FS)
PARAMETERS: p_bukrs  TYPE jvso1-rbukrs OBLIGATORY DEFAULT 'T001'.

* Fiscal Year (mandatory)
PARAMETERS: p_year   TYPE jvso1-ryear  OBLIGATORY DEFAULT sy-datum(4).

* Posting Period (mandatory)
PARAMETERS: p_perio  TYPE jvso1-poper  OBLIGATORY.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-b02.

* Test Run checkbox - if checked, no actual BAPI posting will occur
PARAMETERS: p_test   AS CHECKBOX DEFAULT 'X'.

SELECTION-SCREEN END OF BLOCK b2.
