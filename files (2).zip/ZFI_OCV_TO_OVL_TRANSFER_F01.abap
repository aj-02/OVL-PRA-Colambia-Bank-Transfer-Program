*&---------------------------------------------------------------------*
*&  Include           ZFI_OCV_TO_OVL_TRANSFER_F01
*&---------------------------------------------------------------------*
*& Description : Subroutines (FORM routines) containing all logic for
*&               document transfer from Colombia OCV to OVL.
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  VALIDATE_COMPANY_CODE
*&---------------------------------------------------------------------*
*  Validate that the entered company code exists in T001
*----------------------------------------------------------------------*
FORM validate_company_code USING iv_bukrs TYPE bukrs.

  DATA: lv_bukrs TYPE t001-bukrs.

  SELECT SINGLE bukrs
    FROM t001
    INTO lv_bukrs
    WHERE bukrs = iv_bukrs.

  IF sy-subrc <> 0.
    MESSAGE e000(zmsg) WITH 'Invalid Company Code' iv_bukrs.
*   NOTE: Replace 'ZMSG' with the actual message class used in the
*   project. Generic error message used here as a placeholder.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  VALIDATE_FISCAL_YEAR
*&---------------------------------------------------------------------*
*  Validate fiscal year is in a reasonable range
*----------------------------------------------------------------------*
FORM validate_fiscal_year USING iv_year TYPE gjahr.

  DATA: lv_curr_year TYPE gjahr.

  lv_curr_year = sy-datum(4).

* Year cannot be in the far future or far past
  IF iv_year > lv_curr_year OR iv_year < ( lv_curr_year - 10 ).
    MESSAGE e001(zmsg) WITH 'Invalid Fiscal Year' iv_year.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  VALIDATE_PERIOD
*&---------------------------------------------------------------------*
*  Validate posting period is between 1 and 16
*----------------------------------------------------------------------*
FORM validate_period USING iv_period TYPE poper.

  IF iv_period < '001' OR iv_period > '016'.
    MESSAGE e002(zmsg) WITH 'Invalid Period - must be between 1 and 16'.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  LOAD_MAPPING_TABLES
*&---------------------------------------------------------------------*
*  Load all custom mapping Z-tables into internal tables (one-time read)
*  Mapping tables described in the FS:
*     ZJVMAP   - Company / JV / Recovery Indicator mapping
*     ZGLMAP   - GL account mapping
*     ZCSKMAP  - Cost Center mapping
*     ZWBSMAP  - WBS Element mapping
*     ZPCMAP   - Profit Center mapping
*----------------------------------------------------------------------*
FORM load_mapping_tables.

  DATA: ls_jv_map  TYPE ty_jv_map.

* ---------------------------------------------------------------------
* 1) Load JV / Recovery Indicator mapping
*    Only JVs with VTYPE 2 and 5 are valid (per FS).
*    Join with T8JV to enforce this restriction.
* ---------------------------------------------------------------------
  SELECT z~op_bukrs z~op_jv z~op_recin
         z~rc_bukrs z~rc_jv z~rc_recin
    INTO TABLE gt_jv_map
    FROM zjvmap AS z
    INNER JOIN t8jv AS op
      ON op~bukrs = z~op_bukrs
     AND op~vname = z~op_jv
    INNER JOIN t8jv AS rc
      ON rc~bukrs = z~rc_bukrs
     AND rc~vname = z~rc_jv
   WHERE z~op_bukrs = p_bukrs
     AND op~vtype IN ( gc_vtype_2, gc_vtype_5 )
     AND rc~vtype IN ( gc_vtype_2, gc_vtype_5 ).

  IF sy-subrc <> 0.
    MESSAGE 'No JV mapping records found for Operating Co.Code'
            TYPE 'E'.
  ENDIF.

* ---------------------------------------------------------------------
* 2) Load GL mapping (operating company codes restricted to those
*    present in the JV mapping table - per FS)
* ---------------------------------------------------------------------
  IF gt_jv_map IS NOT INITIAL.
    SELECT op_bukrs op_gl rc_bukrs rc_gl
      INTO TABLE gt_gl_map
      FROM zglmap
       FOR ALL ENTRIES IN gt_jv_map
     WHERE op_bukrs = gt_jv_map-op_bukrs.
  ENDIF.

* ---------------------------------------------------------------------
* 3) Load Cost Center mapping
* ---------------------------------------------------------------------
  IF gt_jv_map IS NOT INITIAL.
    SELECT op_bukrs op_cntr rc_bukrs rc_cntr
      INTO TABLE gt_csk_map
      FROM zcskmap
       FOR ALL ENTRIES IN gt_jv_map
     WHERE op_bukrs = gt_jv_map-op_bukrs.
  ENDIF.

* ---------------------------------------------------------------------
* 4) Load WBS Element mapping
* ---------------------------------------------------------------------
  IF gt_jv_map IS NOT INITIAL.
    SELECT op_bukrs op_wbs rc_bukrs rc_wbs
      INTO TABLE gt_wbs_map
      FROM zwbsmap
       FOR ALL ENTRIES IN gt_jv_map
     WHERE op_bukrs = gt_jv_map-op_bukrs.
  ENDIF.

* ---------------------------------------------------------------------
* 5) Load Profit Center mapping
* ---------------------------------------------------------------------
  IF gt_jv_map IS NOT INITIAL.
    SELECT op_bukrs op_prctr rc_bukrs rc_prctr
      INTO TABLE gt_pc_map
      FROM zpcmap
       FOR ALL ENTRIES IN gt_jv_map
     WHERE op_bukrs = gt_jv_map-op_bukrs.
  ENDIF.

* Sort all mapping tables for binary search reads
  SORT gt_jv_map  BY op_bukrs op_jv op_recin.
  SORT gt_gl_map  BY op_bukrs op_gl.
  SORT gt_csk_map BY op_bukrs op_cntr.
  SORT gt_wbs_map BY op_bukrs op_wbs.
  SORT gt_pc_map  BY op_bukrs op_prctr.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  READ_JVSO1_DATA
*&---------------------------------------------------------------------*
*  Read source venture data from JVSO1 using filters from the FS:
*    RLDNR  = '4A' or '4C'
*    RRCTY  = '0'
*    RVERS  = '1'
*    RYEAR  = selection screen
*    POPER  = selection screen
*    RJVNAM = JVs from JV mapping table (Operating JVs)
*    RRECIN = Recovery Indicators from JV mapping (Operating)
*    RACCT  = GL accounts from GL mapping (Operating)
*----------------------------------------------------------------------*
FORM read_jvso1_data.

  DATA: lr_jv     TYPE RANGE OF jv_name,
        ls_jv     LIKE LINE OF lr_jv,
        lr_recin  TYPE RANGE OF jv_recind,
        ls_recin  LIKE LINE OF lr_recin,
        lr_acct   TYPE RANGE OF racct,
        ls_acct   LIKE LINE OF lr_acct,
        ls_jv_map TYPE ty_jv_map,
        ls_gl_map TYPE ty_gl_map.

* Build range for Operating JVs from JV mapping table
  LOOP AT gt_jv_map INTO ls_jv_map.
    ls_jv-sign   = 'I'.
    ls_jv-option = 'EQ'.
    ls_jv-low    = ls_jv_map-op_jv.
    APPEND ls_jv TO lr_jv.

    ls_recin-sign   = 'I'.
    ls_recin-option = 'EQ'.
    ls_recin-low    = ls_jv_map-op_recin.
    APPEND ls_recin TO lr_recin.
  ENDLOOP.

* Build range for GL accounts from GL mapping
  LOOP AT gt_gl_map INTO ls_gl_map.
    ls_acct-sign   = 'I'.
    ls_acct-option = 'EQ'.
    ls_acct-low    = ls_gl_map-op_gl.
    APPEND ls_acct TO lr_acct.
  ENDLOOP.

* Remove duplicates from ranges
  SORT: lr_jv, lr_recin, lr_acct.
  DELETE ADJACENT DUPLICATES FROM lr_jv.
  DELETE ADJACENT DUPLICATES FROM lr_recin.
  DELETE ADJACENT DUPLICATES FROM lr_acct.

* Read JVSO1
  SELECT rldnr  rrcty  rvers  ryear  poper
         rbukrs rjvnam rrecin racct
         regrou rcntr  rordnr rprojk rprctr
         tsl    hsl    ksl    budat  rtcur
    INTO TABLE gt_jvso1
    FROM jvso1
    WHERE rldnr  IN ( gc_ledger_4a, gc_ledger_4c )
      AND rrcty  =  gc_rrcty
      AND rvers  =  gc_rvers
      AND ryear  =  p_year
      AND poper  =  p_perio
      AND rbukrs =  p_bukrs
      AND rjvnam IN lr_jv
      AND rrecin IN lr_recin
      AND racct  IN lr_acct.

  IF sy-subrc <> 0.
    MESSAGE 'No data found in JVSO1 for the given selection criteria'
            TYPE 'I'.
    STOP.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  AGGREGATE_SOURCE_DATA
*&---------------------------------------------------------------------*
*  Per FS: "Subtotal at RJVNAM / RRECIN / RACCT / RCNTR / RORDNR /
*           RPROJK / RPRCTR for TSL / HSL / KSL"
*  Aggregate the source data by these key fields.
*----------------------------------------------------------------------*
FORM aggregate_source_data.

  DATA: ls_aggr TYPE ty_aggregated.

* Sort by all key fields for control-level processing
  SORT gt_jvso1 BY rbukrs rjvnam rrecin racct
                   rcntr rordnr rprojk rprctr.

  LOOP AT gt_jvso1 INTO gs_jvso1.

*   Initialize aggregation record on first iteration / key change
    IF ls_aggr-rjvnam IS INITIAL.
      ls_aggr-rbukrs = gs_jvso1-rbukrs.
      ls_aggr-rjvnam = gs_jvso1-rjvnam.
      ls_aggr-rrecin = gs_jvso1-rrecin.
      ls_aggr-racct  = gs_jvso1-racct.
      ls_aggr-rcntr  = gs_jvso1-rcntr.
      ls_aggr-rordnr = gs_jvso1-rordnr.
      ls_aggr-rprojk = gs_jvso1-rprojk.
      ls_aggr-rprctr = gs_jvso1-rprctr.
      ls_aggr-budat  = gs_jvso1-budat.
      ls_aggr-rtcur  = gs_jvso1-rtcur.
    ENDIF.

*   Accumulate amounts
    ls_aggr-tsl = ls_aggr-tsl + gs_jvso1-tsl.
    ls_aggr-hsl = ls_aggr-hsl + gs_jvso1-hsl.
    ls_aggr-ksl = ls_aggr-ksl + gs_jvso1-ksl.

*   On key change: append accumulated record, reset
    AT END OF rprctr.
      APPEND ls_aggr TO gt_aggregated.
      CLEAR ls_aggr.
    ENDAT.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DETERMINE_CURRENCIES
*&---------------------------------------------------------------------*
*  Per FS: "Use JV_AND_FI_CURRENCIES to map the Currencies of Sender
*           Co.Code and Receiver Co.Code"
*  This FM returns FI and JV currency settings for the given co.code.
*----------------------------------------------------------------------*
FORM determine_currencies.

  DATA: lv_waers_op   TYPE waers,
        lv_waers_rc   TYPE waers,
        lt_currencies TYPE STANDARD TABLE OF t8jc.

* ---------------------------------------------------------------------
* Get currency for SENDING (Operating) company code
* NOTE: JV_AND_FI_CURRENCIES is a JV-specific FM. Signature assumed
*       based on common usage; verify the exact import/export
*       parameters in the development system before activation.
* ---------------------------------------------------------------------
  CALL FUNCTION 'JV_AND_FI_CURRENCIES'
    EXPORTING
      i_bukrs            = p_bukrs
    IMPORTING
      e_local_currency   = lv_waers_op
    EXCEPTIONS
      currency_not_found = 1
      OTHERS             = 2.

  IF sy-subrc <> 0.
*   Fallback: read directly from T001
    SELECT SINGLE waers FROM t001
      INTO lv_waers_op
     WHERE bukrs = p_bukrs.
  ENDIF.

  gv_src_curr = lv_waers_op.

* Receiver currency is determined per-line based on the mapped
* receiving company code (handled inside APPLY_MAPPINGS).

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  APPLY_MAPPINGS
*&---------------------------------------------------------------------*
*  For each aggregated record, look up the receiving values from the
*  Z mapping tables and build GT_POST.
*----------------------------------------------------------------------*
FORM apply_mappings.

  DATA: ls_jv_map  TYPE ty_jv_map,
        ls_gl_map  TYPE ty_gl_map,
        ls_csk_map TYPE ty_csk_map,
        ls_wbs_map TYPE ty_wbs_map,
        ls_pc_map  TYPE ty_pc_map,
        lv_waers   TYPE waers.

  LOOP AT gt_aggregated INTO gs_aggregated.

    CLEAR gs_post.

*   --- Copy source values ---
    gs_post-src_bukrs = gs_aggregated-rbukrs.
    gs_post-src_jv    = gs_aggregated-rjvnam.
    gs_post-src_recin = gs_aggregated-rrecin.
    gs_post-src_acct  = gs_aggregated-racct.
    gs_post-src_cntr  = gs_aggregated-rcntr.
    gs_post-src_order = gs_aggregated-rordnr.
    gs_post-src_wbs   = gs_aggregated-rprojk.
    gs_post-src_prctr = gs_aggregated-rprctr.
    gs_post-tsl       = gs_aggregated-tsl.
    gs_post-hsl       = gs_aggregated-hsl.
    gs_post-ksl       = gs_aggregated-ksl.
    gs_post-src_curr  = gs_aggregated-rtcur.
    gs_post-budat     = gs_aggregated-budat.

*   --- 1) Map JV / Recovery Indicator ---
    READ TABLE gt_jv_map INTO ls_jv_map
         WITH KEY op_bukrs = gs_aggregated-rbukrs
                  op_jv    = gs_aggregated-rjvnam
                  op_recin = gs_aggregated-rrecin
         BINARY SEARCH.

    IF sy-subrc = 0.
      gs_post-rec_bukrs = ls_jv_map-rc_bukrs.
      gs_post-rec_jv    = ls_jv_map-rc_jv.
      gs_post-rec_recin = ls_jv_map-rc_recin.
    ELSE.
*     Skip this line if no JV mapping is found (cannot post)
      CLEAR gs_log.
      gs_log-src_bukrs = gs_aggregated-rbukrs.
      gs_log-src_jv    = gs_aggregated-rjvnam.
      gs_log-msgtyp    = 'E'.
      CONCATENATE 'No JV mapping found for'
                  gs_aggregated-rjvnam '/'
                  gs_aggregated-rrecin
             INTO gs_log-message SEPARATED BY space.
      APPEND gs_log TO gt_log.
      CONTINUE.
    ENDIF.

*   --- 2) Map GL Account ---
    READ TABLE gt_gl_map INTO ls_gl_map
         WITH KEY op_bukrs = gs_aggregated-rbukrs
                  op_gl    = gs_aggregated-racct
         BINARY SEARCH.

    IF sy-subrc = 0.
      gs_post-rec_acct = ls_gl_map-rc_gl.
    ELSE.
      CLEAR gs_log.
      gs_log-src_bukrs = gs_aggregated-rbukrs.
      gs_log-msgtyp    = 'E'.
      CONCATENATE 'No GL mapping found for account'
                  gs_aggregated-racct
             INTO gs_log-message SEPARATED BY space.
      APPEND gs_log TO gt_log.
      CONTINUE.
    ENDIF.

*   --- 3) Map Cost Center (if present on source line) ---
    IF gs_aggregated-rcntr IS NOT INITIAL.
      READ TABLE gt_csk_map INTO ls_csk_map
           WITH KEY op_bukrs = gs_aggregated-rbukrs
                    op_cntr  = gs_aggregated-rcntr
           BINARY SEARCH.

      IF sy-subrc = 0.
        gs_post-rec_cntr = ls_csk_map-rc_cntr.
      ENDIF.
*     If no mapping is found, leave receiver cost center initial.
*     Posting will rely on Profit Center / WBS / Order instead.
    ENDIF.

*   --- 4) Map WBS Element (if present) ---
    IF gs_aggregated-rprojk IS NOT INITIAL.
      READ TABLE gt_wbs_map INTO ls_wbs_map
           WITH KEY op_bukrs = gs_aggregated-rbukrs
                    op_wbs   = gs_aggregated-rprojk
           BINARY SEARCH.

      IF sy-subrc = 0.
        gs_post-rec_wbs = ls_wbs_map-rc_wbs.
      ENDIF.
    ENDIF.

*   --- 5) Map Profit Center ---
    IF gs_aggregated-rprctr IS NOT INITIAL.
      READ TABLE gt_pc_map INTO ls_pc_map
           WITH KEY op_bukrs = gs_aggregated-rbukrs
                    op_prctr = gs_aggregated-rprctr
           BINARY SEARCH.

      IF sy-subrc = 0.
        gs_post-rec_prctr = ls_pc_map-rc_prctr.
      ENDIF.
    ENDIF.

*   --- 6) Internal Order is carried over as-is ---
*       FS does not define a mapping for internal orders. We pass the
*       source order to the receiver line; adjust if a mapping table
*       (e.g. ZAUFMAP) is later introduced.
    gs_post-rec_order = gs_aggregated-rordnr.

*   --- 7) Determine receiver currency ---
    SELECT SINGLE waers FROM t001
      INTO lv_waers
     WHERE bukrs = gs_post-rec_bukrs.
    gs_post-rec_curr = lv_waers.

    APPEND gs_post TO gt_post.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DERIVE_POSTING_DATE
*&---------------------------------------------------------------------*
*  Per FS: "Based on BUDAT, get the Last day of that month, and use
*           this as Document Date / Posting Date for the receiving
*           Co.Code"
*----------------------------------------------------------------------*
FORM derive_posting_date.

  DATA: lv_last_day TYPE budat.

  LOOP AT gt_post INTO gs_post.

*   Determine the last day of the month corresponding to BUDAT
    CALL FUNCTION 'LAST_DAY_OF_MONTHS'
      EXPORTING
        day_in            = gs_post-budat
      IMPORTING
        last_day_of_month = lv_last_day
      EXCEPTIONS
        day_in_no_date    = 1
        OTHERS            = 2.

    IF sy-subrc = 0.
      gs_post-post_date = lv_last_day.
      gs_post-doc_date  = lv_last_day.
    ELSE.
*     Fallback - use current date (should not happen in normal flow)
      gs_post-post_date = sy-datum.
      gs_post-doc_date  = sy-datum.
    ENDIF.

    MODIFY gt_post FROM gs_post.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  POST_DOCUMENTS
*&---------------------------------------------------------------------*
*  Post the receiver-side documents using BAPI_ACCOUNTING_DOCUMENT_POST.
*  Documents are grouped by receiver company code + posting date so that
*  one document is created per group (debit and credit lines balanced).
*----------------------------------------------------------------------*
FORM post_documents.

  DATA: lt_group  TYPE STANDARD TABLE OF ty_post,
        ls_group  TYPE ty_post,
        lv_curr_bukrs TYPE bukrs,
        lv_curr_date  TYPE budat.

* Sort by receiver Co.Code + posting date to enable grouping
  SORT gt_post BY rec_bukrs post_date.

  LOOP AT gt_post INTO gs_post.

    AT NEW post_date.
      CLEAR lt_group.
    ENDAT.

    APPEND gs_post TO lt_group.

    AT END OF post_date.
*     Post one document for this group of items
      PERFORM call_bapi_post USING lt_group.
      CLEAR lt_group.
    ENDAT.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  CALL_BAPI_POST
*&---------------------------------------------------------------------*
*  Build BAPI structures and call BAPI_ACCOUNTING_DOCUMENT_POST.
*----------------------------------------------------------------------*
FORM call_bapi_post USING it_group TYPE STANDARD TABLE.

  DATA: ls_post     TYPE ty_post,
        lv_itemno   TYPE posnr_acc VALUE 0,
        lv_total_dr TYPE bapiaccr09-amt_doccur,
        lv_total_cr TYPE bapiaccr09-amt_doccur,
        ls_first    TYPE ty_post,
        lv_refdoc   TYPE bapiache09-ref_doc_no,
        lv_text     TYPE bapiacgl09-item_text.

* Clear BAPI working areas
  CLEAR: gs_doc_header, gt_accountgl, gt_currency, gt_return,
         gv_obj_type, gv_obj_key, gv_obj_sys.

* Read first record to derive header information
  READ TABLE it_group INTO ls_first INDEX 1.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

* ---------------------------------------------------------------------
* Populate Document Header (BAPIACHE09)
* ---------------------------------------------------------------------
  gs_doc_header-username   = sy-uname.
  gs_doc_header-header_txt = 'Transfer OCV to OVL'.
  gs_doc_header-comp_code   = ls_first-rec_bukrs.
  gs_doc_header-doc_date    = ls_first-doc_date.
  gs_doc_header-pstng_date  = ls_first-post_date.
  gs_doc_header-doc_type    = gc_doc_type.       " Assumed 'SA'
* NOTE: Reference fields not specified in FS - build a meaningful key
*       so the source document can be traced back. Adjust per business
*       requirement.
  CONCATENATE 'OCV' ls_first-src_bukrs p_year p_perio
         INTO lv_refdoc.
  gs_doc_header-ref_doc_no  = lv_refdoc.
  gs_doc_header-bus_act     = 'RFBU'.            " Standard FI activity

* Fiscal year and period:
* NOTE: BAPIACHE09 does not have explicit FISCYEAR/PERIOD fields - the
*       BAPI derives them from PSTNG_DATE. If a different fiscal year
*       variant requires explicit setting, use the Extension2 parameter.

* ---------------------------------------------------------------------
* Build line items
*  Per FS, the source venture is offset (credited/debited away) and
*  the receiver venture is debited/credited correspondingly. We
*  generate two line items per source aggregated record:
*   - Line 1: Credit on source GL/JV (reversing the original)
*   - Line 2: Debit  on receiver GL/JV (new posting)
*  NOTE: The actual debit/credit direction may depend on whether the
*  source TSL/HSL is positive or negative. Logic below handles both.
* ---------------------------------------------------------------------
  LOOP AT it_group INTO ls_post.

*   --- Line 1: Source side (offset / clearing) ---
    lv_itemno = lv_itemno + 1.
    CLEAR gs_accountgl.
    gs_accountgl-itemno_acc = lv_itemno.
    gs_accountgl-gl_account = ls_post-src_acct.
    gs_accountgl-comp_code  = ls_post-src_bukrs.
    gs_accountgl-fisc_year  = p_year.
    gs_accountgl-fis_period = p_perio.
    gs_accountgl-pstng_date = ls_post-post_date.
    gs_accountgl-doc_type   = gc_doc_type.
*   Cost objects (only one of these should be filled per SAP rules)
    gs_accountgl-costcenter = ls_post-src_cntr.
    gs_accountgl-orderid    = ls_post-src_order.
    gs_accountgl-wbs_element = ls_post-src_wbs.
    gs_accountgl-profit_ctr = ls_post-src_prctr.
*   JV-specific fields (custom extension - JV fields may need to be
*   populated via EXTENSION2 if not natively supported by BAPI in
*   the system release. Adjust accordingly.)
*   gs_accountgl-jv_name    = ls_post-src_jv.
*   gs_accountgl-recov_ind  = ls_post-src_recin.
    CONCATENATE 'OCV->OVL transfer' ls_post-src_jv
           INTO lv_text SEPARATED BY space.
    gs_accountgl-item_text  = lv_text.
    APPEND gs_accountgl TO gt_accountgl.

*   Currency / amount for source line (credit - negate amount)
    CLEAR gs_currency.
    gs_currency-itemno_acc = lv_itemno.
    gs_currency-currency   = ls_post-src_curr.
    gs_currency-amt_doccur = ls_post-tsl * -1.   " reverse sign
*   NOTE: If dual currency posting is required, also fill AMT_BASE
*   and additional lines for HSL/KSL. The exact requirement should
*   be confirmed - left as a comment for now.
*   gs_currency-amt_base = ls_post-hsl.
    APPEND gs_currency TO gt_currency.

*   --- Line 2: Receiver side ---
    lv_itemno = lv_itemno + 1.
    CLEAR gs_accountgl.
    gs_accountgl-itemno_acc = lv_itemno.
    gs_accountgl-gl_account = ls_post-rec_acct.
    gs_accountgl-comp_code  = ls_post-rec_bukrs.
    gs_accountgl-fisc_year  = p_year.
    gs_accountgl-fis_period = p_perio.
    gs_accountgl-pstng_date = ls_post-post_date.
    gs_accountgl-doc_type   = gc_doc_type.
    gs_accountgl-costcenter = ls_post-rec_cntr.
    gs_accountgl-orderid    = ls_post-rec_order.
    gs_accountgl-wbs_element = ls_post-rec_wbs.
    gs_accountgl-profit_ctr = ls_post-rec_prctr.
*   gs_accountgl-jv_name    = ls_post-rec_jv.
*   gs_accountgl-recov_ind  = ls_post-rec_recin.
    CONCATENATE 'OCV->OVL transfer' ls_post-rec_jv
           INTO lv_text SEPARATED BY space.
    gs_accountgl-item_text  = lv_text.
    APPEND gs_accountgl TO gt_accountgl.

*   Currency / amount for receiver line (debit - positive amount)
    CLEAR gs_currency.
    gs_currency-itemno_acc = lv_itemno.
    gs_currency-currency   = ls_post-rec_curr.
    gs_currency-amt_doccur = ls_post-tsl.
*   NOTE: If source and receiver currencies differ, perform currency
*   conversion here via CONVERT_TO_LOCAL_CURRENCY. Left as a comment
*   pending business confirmation of the FX strategy.
*   IF ls_post-src_curr <> ls_post-rec_curr.
*     PERFORM convert_currency USING ls_post-tsl
*                                    ls_post-src_curr
*                                    ls_post-rec_curr
*                                    ls_post-post_date
*                           CHANGING gs_currency-amt_doccur.
*   ENDIF.
    APPEND gs_currency TO gt_currency.

  ENDLOOP.

* ---------------------------------------------------------------------
* Call BAPI_ACCOUNTING_DOCUMENT_CHECK first for validation
* ---------------------------------------------------------------------
  CALL FUNCTION 'BAPI_ACCOUNTING_DOCUMENT_CHECK'
    EXPORTING
      documentheader = gs_doc_header
    TABLES
      accountgl      = gt_accountgl
      currencyamount = gt_currency
      return         = gt_return.

* Check for any errors in the return table
  READ TABLE gt_return INTO gs_return WITH KEY type = 'E'.
  IF sy-subrc = 0.
*   Validation failed - log all error messages and skip posting
    LOOP AT gt_return INTO gs_return WHERE type CA 'EA'.
      CLEAR gs_log.
      gs_log-src_bukrs = ls_first-src_bukrs.
      gs_log-rec_bukrs = ls_first-rec_bukrs.
      gs_log-msgtyp    = gs_return-type.
      gs_log-message   = gs_return-message.
      APPEND gs_log TO gt_log.
    ENDLOOP.
    gv_err_count = gv_err_count + 1.
    RETURN.
  ENDIF.

* ---------------------------------------------------------------------
* If test run, skip actual posting
* ---------------------------------------------------------------------
  IF p_test = 'X'.
    CLEAR gs_log.
    gs_log-src_bukrs = ls_first-src_bukrs.
    gs_log-rec_bukrs = ls_first-rec_bukrs.
    gs_log-msgtyp    = 'S'.
    gs_log-message   = 'TEST RUN - Document validated successfully, no posting performed'.
    APPEND gs_log TO gt_log.
    RETURN.
  ENDIF.

* ---------------------------------------------------------------------
* Call BAPI_ACCOUNTING_DOCUMENT_POST for actual posting
* ---------------------------------------------------------------------
  CLEAR gt_return.
  CALL FUNCTION 'BAPI_ACCOUNTING_DOCUMENT_POST'
    EXPORTING
      documentheader = gs_doc_header
    IMPORTING
      obj_type       = gv_obj_type
      obj_key        = gv_obj_key
      obj_sys        = gv_obj_sys
    TABLES
      accountgl      = gt_accountgl
      currencyamount = gt_currency
      return         = gt_return.

* Check for errors
  READ TABLE gt_return INTO gs_return WITH KEY type = 'E'.
  IF sy-subrc = 0.
*   Rollback on error
    CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
    LOOP AT gt_return INTO gs_return WHERE type CA 'EA'.
      CLEAR gs_log.
      gs_log-src_bukrs = ls_first-src_bukrs.
      gs_log-rec_bukrs = ls_first-rec_bukrs.
      gs_log-msgtyp    = gs_return-type.
      gs_log-message   = gs_return-message.
      APPEND gs_log TO gt_log.
    ENDLOOP.
    gv_err_count = gv_err_count + 1.
  ELSE.
*   Commit the work to actually persist the document
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait = 'X'.

*   OBJ_KEY contains BELNR (1-10) + BUKRS (11-14) + GJAHR (15-18)
    CLEAR gs_log.
    gs_log-src_bukrs = ls_first-src_bukrs.
    gs_log-rec_bukrs = ls_first-rec_bukrs.
    gs_log-belnr     = gv_obj_key(10).
    gs_log-gjahr     = gv_obj_key+14(4).
    gs_log-msgtyp    = 'S'.
    CONCATENATE 'Document' gs_log-belnr 'posted successfully for'
                ls_first-rec_bukrs
           INTO gs_log-message SEPARATED BY space.
    APPEND gs_log TO gt_log.
    gv_doc_count = gv_doc_count + 1.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_LOG
*&---------------------------------------------------------------------*
*  Display the processing log in ALV grid format.
*----------------------------------------------------------------------*
FORM display_log.

  DATA: lo_alv     TYPE REF TO cl_salv_table,
        lo_columns TYPE REF TO cl_salv_columns_table,
        lo_column  TYPE REF TO cl_salv_column,
        lo_functions TYPE REF TO cl_salv_functions_list,
        lx_msg     TYPE REF TO cx_salv_msg.

  IF gt_log IS INITIAL.
    MESSAGE 'No log entries to display' TYPE 'I'.
    RETURN.
  ENDIF.

* Display summary first
  WRITE: / 'Transfer of documents from Colombia OCV to OVL - Summary'.
  WRITE: / 'Documents posted    :', gv_doc_count.
  WRITE: / 'Errors encountered  :', gv_err_count.
  WRITE: / 'Test run flag       :', p_test.
  SKIP.

* Display the log table using ALV
  TRY.
      cl_salv_table=>factory(
        IMPORTING
          r_salv_table = lo_alv
        CHANGING
          t_table      = gt_log ).

*     Enable standard functions (sort, filter, export, etc.)
      lo_functions = lo_alv->get_functions( ).
      lo_functions->set_all( 'X' ).

*     Optimize column widths
      lo_columns = lo_alv->get_columns( ).
      lo_columns->set_optimize( 'X' ).

      lo_alv->display( ).

    CATCH cx_salv_msg INTO lx_msg.
*     Fallback - write the log as a classic list
      LOOP AT gt_log INTO gs_log.
        WRITE: / gs_log-src_bukrs,
                 gs_log-rec_bukrs,
                 gs_log-belnr,
                 gs_log-gjahr,
                 gs_log-msgtyp,
                 gs_log-message.
      ENDLOOP.
  ENDTRY.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  CONVERT_CURRENCY
*&---------------------------------------------------------------------*
*  Helper to perform currency conversion when source and receiver
*  currencies differ. Called optionally from CALL_BAPI_POST.
*  NOTE: Wire this in only after the business confirms the FX strategy
*  (exchange rate type, translation date, etc.).
*----------------------------------------------------------------------*
FORM convert_currency USING    iv_amount   TYPE jvso1-tsl
                               iv_from_cur TYPE waers
                               iv_to_cur   TYPE waers
                               iv_date     TYPE budat
                      CHANGING cv_amount   TYPE bapiaccr09-amt_doccur.

  CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
    EXPORTING
      date             = iv_date
      foreign_amount   = iv_amount
      foreign_currency = iv_from_cur
      local_currency   = iv_to_cur
*     TYPE_OF_RATE     = 'M'                    " Standard rate type
    IMPORTING
      local_amount     = cv_amount
    EXCEPTIONS
      no_rate_found    = 1
      overflow         = 2
      no_factors_found = 3
      no_spread_found  = 4
      derived_2_times  = 5
      OTHERS           = 6.

  IF sy-subrc <> 0.
*   On conversion failure, keep original amount and log a warning
    cv_amount = iv_amount.
  ENDIF.

ENDFORM.
