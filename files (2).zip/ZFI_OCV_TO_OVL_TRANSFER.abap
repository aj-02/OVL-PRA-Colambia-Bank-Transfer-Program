*&---------------------------------------------------------------------*
*& Report  ZFI_OCV_TO_OVL_TRANSFER
*&---------------------------------------------------------------------*
*& Description : Transfer of documents from Colombia OCV to OVL
*&               - Transfer Cutback Items from Venture 2
*&               - Transfer NB Items from Venture 2
*&               - Transfer Corporate Items
*& Author      : <Developer Name>
*& Date        : <Creation Date>
*& Transport   : <TR Number>
*&---------------------------------------------------------------------*
*& Change History
*&---------------------------------------------------------------------*
*& Date        Author              Description
*& ----------  ------------------  ------------------------------------
*& DD.MM.YYYY  <Developer Name>    Initial Development
*&---------------------------------------------------------------------*
REPORT zfi_ocv_to_ovl_transfer.

* Include for global data declarations (Types, Tables, Data, Constants,
* Selection Screen)
INCLUDE zfi_ocv_to_ovl_transfer_top.

* Include for AT SELECTION-SCREEN / START-OF-SELECTION / END-OF-SELECTION
* event blocks
INCLUDE zfi_ocv_to_ovl_transfer_e01.

* Include for FORM routines / Subroutines
INCLUDE zfi_ocv_to_ovl_transfer_f01.
